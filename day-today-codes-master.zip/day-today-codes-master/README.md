# day-today-codes
All those needed handy code snippets
